#!/bin/sh

# NOTE: make sure `mvn install` in /gprc is executed before running this test
mvn test
