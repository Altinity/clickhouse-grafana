rootProject.name = "flatbuffers-kotlin"
include("flatbuffers-kotlin")
include("benchmark")
