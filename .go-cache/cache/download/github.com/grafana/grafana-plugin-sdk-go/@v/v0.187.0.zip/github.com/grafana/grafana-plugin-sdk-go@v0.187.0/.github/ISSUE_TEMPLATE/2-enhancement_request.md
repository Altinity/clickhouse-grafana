---
name: Enhancement request
about: Suggest an enhancement or new feature
labels: 'enhancement'
---

<!-- Please only use this template for submitting enhancement requests -->

**What would you like to be added**:

**Why is this needed**:
