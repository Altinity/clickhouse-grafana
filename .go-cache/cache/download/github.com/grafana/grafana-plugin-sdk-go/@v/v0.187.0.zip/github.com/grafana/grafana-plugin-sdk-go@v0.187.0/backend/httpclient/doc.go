// Package httpclient provides HTTP client and outgoing HTTP request middleware.
package httpclient
