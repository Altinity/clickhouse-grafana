package data

// TimeSeriesValueFieldName is the standard name for time series value fields
const TimeSeriesValueFieldName = "Value"

// TimeSeriesTimeFieldName is the standard name for time series time fields
const TimeSeriesTimeFieldName = "Time"
