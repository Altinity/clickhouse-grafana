// Package framestruct provides functions to convert from any type to *data.Frame or data.Frames
package framestruct
