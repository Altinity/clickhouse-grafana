# Plugin SDK experimental packages

This package contains experimental packages

## History

- Experimental package `sdata` has been moved into its own package after few experiments here. If you are using `sdata` from plugin SDK, consider it from dataplane package which is available in [`github.com/grafana/dataplane/sdata`](https://github.com/grafana/dataplane/tree/main/sdata).
