// Package live provides types for the Grafana Live server.
package live
