// Package app provides utilities for creating and serving a app plugin over gRPC.
package app
