// Package datasource provides utilities for creating and serving a data source plugin over gRPC.
package datasource
