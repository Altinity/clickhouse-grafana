// Package backend provides SDK handler interfaces and contracts for implementing and serving backend plugins.
package backend
