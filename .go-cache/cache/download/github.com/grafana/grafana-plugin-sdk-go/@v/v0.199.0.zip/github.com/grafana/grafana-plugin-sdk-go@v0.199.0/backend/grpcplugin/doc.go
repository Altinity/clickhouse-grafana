// Package grpcplugin provides support for serving plugin over gRPC.
//
// This package is internal and meant to be used internally by the
// SDK and Grafana.
package grpcplugin
