// Package instancemgmt provides utilities for managing plugin instances.
package instancemgmt
