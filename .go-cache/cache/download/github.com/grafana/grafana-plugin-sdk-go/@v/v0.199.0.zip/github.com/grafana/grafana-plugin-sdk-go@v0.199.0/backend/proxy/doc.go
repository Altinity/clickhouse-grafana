// Package proxy provides utilities for updating a data source plugin connection to go through a proxy.
package proxy
