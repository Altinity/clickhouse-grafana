// Package resource provides utils for handling resource calls.
package resource
