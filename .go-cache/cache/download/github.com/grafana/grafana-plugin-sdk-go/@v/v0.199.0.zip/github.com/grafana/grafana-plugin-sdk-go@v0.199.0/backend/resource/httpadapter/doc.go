// Package httpadapter provides support for handling resource calls using an http.Handler.
package httpadapter
