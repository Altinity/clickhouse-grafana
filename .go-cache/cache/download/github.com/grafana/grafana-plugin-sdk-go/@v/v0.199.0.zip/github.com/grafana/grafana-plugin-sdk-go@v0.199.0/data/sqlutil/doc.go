// Package sqlutil provides multiple utilities for working with SQL data sources.
package sqlutil
