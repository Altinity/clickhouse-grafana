/*
Package sdk is the root of the packages used to access Grafana Plugin SDK for Go.
See https://pkg.go.dev/github.com/grafana/grafana-plugin-sdk-go for a full list of sub-packages.
*/
package sdk // import "github.com/grafana/grafana-plugin-sdk-go"
