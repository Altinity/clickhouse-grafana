# Backend Macros

This is an experimental package to provide support for grafana global variables and frontend macros in the backend.

## Related links

- [\${\_\_from} and \${\_\_to} macros](https://grafana.com/docs/grafana/latest/dashboards/variables/add-template-variables/#__from-and-__to)
