// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

package grpctest

//go:generate protoc -I ./ ./test.proto --go_out=plugins=grpc:.
