// +build mage

package main

func WindowsTarget() {}
