package package1

import "fmt"

func Build() {
	fmt.Println("build")
}
