//+build mage

package main

import (
	//mage:import
	_ "github.com/magefile/mage/mage/testdata/mageimport/tagged/pkg"
)
