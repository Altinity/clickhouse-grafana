//go:build mage
// +build mage

package main

func Build() {}
