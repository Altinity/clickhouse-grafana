package importself

import "fmt"

func Stuff() {
	fmt.Println("stuff")
}