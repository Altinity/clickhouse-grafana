---
title: Basics
weight: 5
pre: "<b>1. </b>"
chapter: true
---

### Chapter 1

# Basics

Discover what this Hugo theme is all about and the core-concepts behind it.
