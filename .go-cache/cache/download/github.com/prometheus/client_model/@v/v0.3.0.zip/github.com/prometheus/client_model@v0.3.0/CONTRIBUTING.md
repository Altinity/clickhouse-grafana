# Contributing

This repository is deprecated. It is only used for specific purposes by the
[Go instrumentation library](https://github.com/prometheus/client_golang).

Therefore, contributions to this repository are only expected to happen as
required by changes in the instrumentation library.
Please see 
[CONTRIBUTING.md](https://github.com/prometheus/client_golang/blob/master/CONTRIBUTING.md) 
of the latter for details.
