log [![Go Walker](http://gowalker.org/api/v1/badge)](http://gowalker.org/github.com/Unknwon/log)
===

Package log is a dead simple, levelable, colorful logging library.

## License

This project is under Apache v2 License. See the [LICENSE](LICENSE) file for the full license text.